from flask import Flask, request
import serial

app = Flask(__name__)

@app.route('/send-ir', methods=['POST'])
def send_ir():
    ir_data = request.form['irData']
    with serial.Serial('/dev/ttyUSB0', 9600, timeout=1) as ser:
        ser.write((ir_data + '\n').encode('utf-8'))
    return {'status': 'success'}

if __name__ == '__main__':
    app.run(host='0.0.0.0')
